﻿CREATE DATABASE Advising_Team_68
GO
CREATE PROC CreateAllTables
As
CREATE TABLE Advisor(
advisor_id INT PRIMARY KEY IDENTITY(1,1),
name VARCHAR(40),
email VARCHAR(40),
office VARCHAR(40),
password VARCHAR(40)
);

CREATE TABLE Student(
student_id INT PRIMARY KEY IDENTITY(1,1),
f_name VARCHAR(40),
l_name VARCHAR(40),
gpa DECIMAL CHECK (gpa BETWEEN 0.7 AND 5),
faculty VARCHAR(40),
email VARCHAR(40),
major VARCHAR(40),
password VARCHAR(40),
financial_status INT,
semester INT ,
acquired_hours INT CHECK(acquired_hours>34),
assigned_hours INT CHECK (assigned_hours<=34),
advisor_id INT,
CONSTRAINT FK_AdvID_Stud_D FOREIGN KEY (advisor_id) REFERENCES Advisor(advisor_id) ON DELETE CASCADE,
CONSTRAINT FK_AdvID_Stud_U FOREIGN KEY (advisor_id) REFERENCES Advisor(advisor_id) ON UPDATE CASCADE
);

CREATE TABLE Student_Phone(
student_id INT,
phone_number VARCHAR(40),
CONSTRAINT FK_StudID_StudPhone_D FOREIGN KEY (student_id) REFERENCES Student (student_id) ON DELETE CASCADE,
CONSTRAINT FK_StudID_StudPhone_U FOREIGN KEY (student_id) REFERENCES Student (student_id) ON UPDATE CASCADE,
PRIMARY KEY (student_id,phone_number)
);

CREATE TABLE Course(
course_id INT PRIMARY KEY IDENTITY(1,1),
name VARCHAR(40),
major VARCHAR(40),
is_offered BIT CHECK 
(is_offered=0 OR is_offered=1),
credit_hours INT,
semester INT
);

CREATE TABLE PreqCourse_course(
prerequisite_course_id INT,
course_id INT,
CONSTRAINT FK_CourID_Preq_D FOREIGN KEY (course_id) REFERENCES Course (course_id ) ON DELETE CASCADE,
CONSTRAINT FK_CourID_Preq_U FOREIGN KEY (course_id) REFERENCES Course (course_id ) ON UPDATE CASCADE,
CONSTRAINT FK_preqCourID_Preq_D FOREIGN KEY (prerequisite_course_id) REFERENCES Course(course_id) ON DELETE NO ACTION,
CONSTRAINT FK_preqCourID_Preq_U FOREIGN KEY (prerequisite_course_id) REFERENCES Course(course_id) ON UPDATE NO ACTION,
PRIMARY KEY (prerequisite_course_id, course_id)
);

CREATE TABLE Instructor(
instructor_id INT PRIMARY KEY IDENTITY(1,1),
name VARCHAR(40),
email VARCHAR(40),
faculty VARCHAR(40),
office VARCHAR(40) 
);


CREATE TABLE Instructor_Course(
course_id INT, 
instructor_id INT,
CONSTRAINT FK_CourID_InstCourse_U FOREIGN KEY (course_id) REFERENCES Course (course_id) ON UPDATE CASCADE,
CONSTRAINT FK_CourID_InstCourse_D FOREIGN KEY (course_id) REFERENCES Course (course_id) ON DELETE CASCADE , 
CONSTRAINT FK_InstID_D FOREIGN KEY (instructor_id) REFERENCES Instructor (instructor_id) ON DELETE CASCADE,
CONSTRAINT FK_InstID_U FOREIGN KEY (instructor_id) REFERENCES Instructor (instructor_id) ON UPDATE CASCADE,
PRIMARY KEY (course_id,instructor_id)
);

CREATE TABLE Student_Instructor_Course_Take (
student_id INT, 
course_id INT,
instructor_id INT,
semester_code VARCHAR(40), 
exam_type VARCHAR(40) Default 'Normal' CHECK (exam_type='Normal' OR exam_type='First_makeup' OR exam_type='Second_makeup'), 
grade VARCHAR (40) Default Null , 
CONSTRAINT FK_StudID_SICT_U FOREIGN KEY (student_id) REFERENCES Student (student_id) ON UPDATE CASCADE,
CONSTRAINT FK_StudID_SICT_D FOREIGN KEY (student_id) REFERENCES Student (student_id) ON DELETE CASCADE ,
CONSTRAINT FK_CourID_SICT_D FOREIGN KEY (course_id) REFERENCES Course (course_id) ON DELETE CASCADE,
CONSTRAINT FK_CourID_SICT_U FOREIGN KEY (course_id) REFERENCES Course (course_id) ON UPDATE CASCADE,
CONSTRAINT FK_InstID_SICT_U FOREIGN KEY ( instructor_id) REFERENCES Instructor ( instructor_id) ON UPDATE CASCADE,
CONSTRAINT FK_InstID_SICT_D FOREIGN KEY ( instructor_id) REFERENCES Instructor ( instructor_id) ON DELETE CASCADE,
PRIMARY KEY (student_id,course_id,semester_code)
);

CREATE TABLE Semester(
semester_code VARCHAR(40) PRIMARY KEY,
start_date DATE, 
end_date DATE
);

CREATE TABLE Course_Semester(
course_id INT, 
semester_code VARCHAR(40),
CONSTRAINT FK_CourID_CourSem_D FOREIGN KEY (course_id) REFERENCES Course (course_id) ON DELETE CASCADE,
CONSTRAINT FK_CourID_CourSem_U FOREIGN KEY(course_id) REFERENCES Course (course_id) ON UPDATE CASCADE,
CONSTRAINT FK_SemCode_CourSem_D FOREIGN KEY (semester_code) REFERENCES Semester (semester_code) ON DELETE CASCADE,
CONSTRAINT FK_SemCode_CourSem_U FOREIGN KEY(semester_code) REFERENCES Semester (semester_code) ON UPDATE CASCADE,
PRIMARY KEY (course_id,semester_code)
);


CREATE TABLE Slot(
slot_id INT PRIMARY KEY IDENTITY (1,1),
day VARCHAR(40),
time VARCHAR(40),
location VARCHAR(40),
course_id INT,
instructor_id INT,
CONSTRAINT FK_CourID_Slot_D FOREIGN KEY (course_id) REFERENCES Course (course_id) ON DELETE CASCADE,
CONSTRAINT FK_CourID_Slot_U FOREIGN KEY(course_id) REFERENCES Course (course_id) ON UPDATE CASCADE,
CONSTRAINT FK_InstID_Slot_D FOREIGN KEY (instructor_id) REFERENCES Instructor (instructor_id) ON DELETE CASCADE,
CONSTRAINT FK_InstID_Slot_U FOREIGN KEY(instructor_id) REFERENCES Instructor (instructor_id) ON UPDATE CASCADE
);

CREATE TABLE Graduation_Plan(
plan_id INT IDENTITY(1,1),
semester_code VARCHAR(40), 
semester_credit_hours INT ,
expected_grad_date Date,
advisor_id INT  , 
student_id INT ,
CONSTRAINT PK_GRAD_PLAN PRIMARY KEY (plan_id, semester_code),
CONSTRAINT FK_AdvID_GP_D FOREIGN KEY (advisor_id) REFERENCES Advisor(advisor_id) ON DELETE CASCADE ,
CONSTRAINT FK_AdvID_GP_U FOREIGN KEY (advisor_id) REFERENCES Advisor(advisor_id) ON UPDATE CASCADE,
CONSTRAINT FK_StudID_GP_D FOREIGN KEY (student_id) REFERENCES Student(student_id) ON DELETE NO ACTION,
CONSTRAINT FK_StudID_GP_U FOREIGN KEY (student_id) REFERENCES Student(student_id) ON UPDATE NO ACTION

);

CREATE TABLE GradPlan_Course(
plan_id INT,
semester_code VARCHAR(40),
course_id INT,
CONSTRAINT PK_GRADPLAN_COURSE PRIMARY KEY (plan_id,semester_code,course_id),
CONSTRAINT FK_PlanID_GPC_D FOREIGN KEY (plan_id, semester_code) REFERENCES Graduation_Plan(plan_id, semester_code) ON DELETE NO ACTION,
CONSTRAINT FK_PlanID_GPC_U FOREIGN KEY (plan_id, semester_code) REFERENCES Graduation_Plan(plan_id,semester_code) ON update NO ACTION,
);

CREATE TABLE Request (
request_id INT PRIMARY KEY IDENTITY(1,1),
type VARCHAR(40), 
comment VARCHAR(40), 
status VARCHAR(40) Default 'pending' CHECK
(status='pending' OR status='approved' OR status='rejected'), 
credit_hours INT,
student_id INT , 
advisor_id INT,
course_id INT,
CONSTRAINT FK_StudID_Req_D FOREIGN KEY (student_id) REFERENCES Student(student_id) ON DELETE CASCADE,
CONSTRAINT FK_StudID_Req_U FOREIGN KEY (student_id) REFERENCES Student(student_id) ON UPDATE CASCADE,
CONSTRAINT FK_AdvID_Req_D FOREIGN KEY (advisor_id) REFERENCES Advisor(advisor_id) ON DELETE NO ACTION,
CONSTRAINT FK_AdvID_Req_U FOREIGN KEY (advisor_id) REFERENCES Advisor(advisor_id) ON UPDATE NO ACTION,
CONSTRAINT FK_CouID_Req_D FOREIGN KEY (course_id) REFERENCES Course(course_id) ON DELETE CASCADE,
CONSTRAINT FK_CouID_Req_U FOREIGN KEY (course_id) REFERENCES Course(course_id) ON UPDATE CASCADE,
);

CREATE TABLE MakeUp_Exam (
exam_id INT PRIMARY KEY IDENTITY(1,1),
date DATETIME, 
type VARCHAR(40) DEFAULT 'Normal' CHECK
(type='Normal' OR type='First MakeUp' OR type='Second MakeUp'),
course_id INT,
CONSTRAINT FK_CourID_ME_D FOREIGN KEY (course_id) REFERENCES Course(course_id) ON DELETE CASCADE,
CONSTRAINT FK_CourID_ME_U FOREIGN KEY (course_id) REFERENCES Course(course_id) ON UPDATE CASCADE
);

CREATE TABLE Exam_Student(
exam_id INT,
student_id INT,
course_id INT,
CONSTRAINT FK_ExamID_ExStud_D FOREIGN KEY (exam_id) REFERENCES MakeUp_Exam (exam_id) ON DELETE CASCADE,
CONSTRAINT FK_ExamID_ExStud_U FOREIGN KEY(exam_id) REFERENCES MakeUp_Exam (exam_id) ON UPDATE CASCADE,
CONSTRAINT FK_StudID_ExStud_D FOREIGN KEY (student_id) REFERENCES Student (student_id) ON DELETE CASCADE,
CONSTRAINT FK_StudID_ExStud_U FOREIGN KEY(student_id) REFERENCES Student (student_id) ON UPDATE CASCADE,
PRIMARY KEY (exam_id,student_id)
);

CREATE TABLE Payment(
payment_id INT PRIMARY KEY IDENTITY(1,1),
amount INT,
deadline DATETIME,
n_installments int,
status VARCHAR(40) DEFAULT'notPaid' CHECK
(status='notPaid' OR status='Paid'),
fund_percentage DECIMAL,
start_date DATETIME,
student_id INT,
semester_code VARCHAR(40),
CONSTRAINT FK_SemCode_Pay_D FOREIGN KEY (semester_code) REFERENCES Semester (semester_code) ON DELETE CASCADE,
CONSTRAINT FK_SemCode_Pay_U FOREIGN KEY(semester_code) REFERENCES Semester (semester_code) ON UPDATE CASCADE,
CONSTRAINT FK_StudID_Pay_D FOREIGN KEY (student_id) REFERENCES Student (student_id) ON DELETE CASCADE,
CONSTRAINT FK_StudID_Pay_U FOREIGN KEY(student_id) REFERENCES Student (student_id) ON UPDATE CASCADE
);

CREATE TABLE Installment(
payment_id INT PRIMARY KEY,
deadline  DATETIME,
amount INT,
status VARCHAR(40),
start_date DATETIME ,
CONSTRAINT FK_PayID_Installment_D FOREIGN KEY (payment_id) REFERENCES Payment (payment_id) ON DELETE CASCADE,
CONSTRAINT FK_PayID_Installment_U FOREIGN KEY(payment_id) REFERENCES Payment (payment_id) ON UPDATE CASCADE
);

EXEC CreateAllTables

-- Adding 10 records to the Course table
INSERT INTO Course(name, major, is_offered, credit_hours, semester)  VALUES
( 'Mathematics 2', 'Science', 1, 3, 2),
( 'CSEN 2', 'Engineering', 1, 4, 2),
( 'Database 1', 'MET', 1, 3, 5),
( 'Physics', 'Science', 0, 4, 1),
( 'CSEN 4', 'Engineering', 1, 3, 4),
( 'Chemistry', 'Engineering', 1, 4, 1),
( 'CSEN 3', 'Engineering', 1, 3, 3),
( 'Computer Architecture', 'MET', 0, 3, 6),
( 'Computer Organization', 'Engineering', 1, 4, 4),
( 'Database2', 'MET', 1, 3, 6);


-- Adding 10 records to the Instructor table
INSERT INTO Instructor(name, email, faculty, office) VALUES
( 'Professor Smith', 'prof.smith@example.com', 'MET', 'Office A'),
( 'Professor Johnson', 'prof.johnson@example.com', 'MET', 'Office B'),
( 'Professor Brown', 'prof.brown@example.com', 'MET', 'Office C'),
( 'Professor White', 'prof.white@example.com', 'MET', 'Office D'),
( 'Professor Taylor', 'prof.taylor@example.com', 'Mechatronics', 'Office E'),
( 'Professor Black', 'prof.black@example.com', 'Mechatronics', 'Office F'),
( 'Professor Lee', 'prof.lee@example.com', 'Mechatronics', 'Office G'),
( 'Professor Miller', 'prof.miller@example.com', 'Mechatronics', 'Office H'),
( 'Professor Davis', 'prof.davis@example.com', 'IET', 'Office I'),
( 'Professor Moore', 'prof.moore@example.com', 'IET', 'Office J');

-- Adding 10 records to the Semester table
INSERT INTO Semester(semester_code, start_date, end_date) VALUES
('W23', '2023-10-01', '2024-01-31'),
('S23', '2023-03-01', '2023-06-30'),
('S23R1', '2023-07-01', '2023-07-31'),
('S23R2', '2023-08-01', '2023-08-31'),
('W24', '2024-10-01', '2025-01-31'),
('S24', '2024-03-01', '2024-06-30'),
('S24R1', '2024-07-01', '2024-07-31'),
('S24R2', '2024-08-01', '2024-08-31')

-- Adding 10 records to the Advisor table
INSERT INTO Advisor(name, email, office, password) VALUES
( 'Dr. Anderson', 'anderson@example.com', 'Office A', 'password1'),
( 'Prof. Baker', 'baker@example.com', 'Office B', 'password2'),
( 'Dr. Carter', 'carter@example.com', 'Office C', 'password3'),
( 'Prof. Davis', 'davis@example.com', 'Office D', 'password4'),
( 'Dr. Evans', 'evans@example.com', 'Office E', 'password5'),
( 'Prof. Foster', 'foster@example.com', 'Office F', 'password6'),
( 'Dr. Green', 'green@example.com', 'Office G', 'password7'),
( 'Prof. Harris', 'harris@example.com', 'Office H', 'password8'),
( 'Dr. Irving', 'irving@example.com', 'Office I', 'password9'),
( 'Prof. Johnson', 'johnson@example.com', 'Office J', 'password10');



-- Adding 10 records to the Student table
INSERT INTO Student (f_name, l_name, GPA, faculty, email, major, password, financial_status, semester, acquired_hours, assigned_hours, advisor_id)   VALUES 
( 'John', 'Doe', 3.5, 'Engineering', 'john.doe@example.com', 'CS', 'password123', 1, 1, 90, 30, 1),
( 'Jane', 'Smith', 3.8, 'Engineering', 'jane.smith@example.com', 'CS', 'password456', 1, 2, 85, 34, 2),
( 'Mike', 'Johnson', 3.2, 'Engineering', 'mike.johnson@example.com', 'CS', 'password789', 1, 3, 75, 34, 3),
( 'Emily', 'White', 3.9, 'Engineering', 'emily.white@example.com', 'CS', 'passwordabc', 0, 4, 95, 34, 4),
( 'David', 'Lee', 3.4, 'Engineering', 'david.lee@example.com', 'IET', 'passworddef', 1, 5, 80, 34, 5),
( 'Grace', 'Brown', 3.7, 'Engineering', 'grace.brown@example.com', 'IET', 'passwordghi', 0, 6, 88, 34, 6),
( 'Robert', 'Miller', 3.1, 'Engineerings', 'robert.miller@example.com', 'IET', 'passwordjkl', 1, 7, 78, 34, 7),
( 'Sophie', 'Clark', 3.6, 'Engineering', 'sophie.clark@example.com', 'Mechatronics', 'passwordmno', 1, 8, 92, 34, 8),
( 'Daniel', 'Wilson', 3.3, 'Engineering', 'daniel.wilson@example.com', 'DMET', 'passwordpqr', 1, 9, 87, 34, 9),
( 'Olivia', 'Anderson', 3.7, 'Engineeringe', 'olivia.anderson@example.com', 'Mechatronics', 'passwordstu', 0, 10, 89, 34, 10);

-- Adding 10 records to the Student_Phone table
INSERT INTO Student_Phone(student_id, phone_number) VALUES
(4, '456-789-0123'),
(5, '567-890-1234'),
(6, '678-901-2345'),
(7, '789-012-3456'),
(8, '890-123-4567'),
(9, '901-234-5678'),
(10, '012-345-6789');


-- Adding 10 records to the PreqCourse_course table
INSERT INTO PreqCourse_course(prerequisite_course_id, course_id) VALUES
(2, 7),
(3, 10),
(2, 4),
(5, 6),
(4, 7),
(6, 8),
(7, 9),
(9, 10),
(9, 1),
(10, 3);


-- Adding 10 records to the Instructor_Course table
INSERT INTO Instructor_Course (instructor_id, course_id) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10);


-- Adding 10 records to the Student_Instructor_Course_Take table
INSERT INTO Student_Instructor_Course_Take (student_id, course_id, instructor_id, semester_code,exam_type, grade) VALUES
(1, 1, 1, 'W23', 'Normal', 'A'),
(2, 2, 2, 'S23', 'First_makeup', 'B'),
(3, 3, 3, 'S23R1', 'Second_makeup', 'C'),
(4, 4, 4, 'S23R2', 'Normal', 'B+'),
(5, 5, 5, 'W23', 'Normal', 'A-'),
(6, 6, 6, 'W24', 'First_makeup', 'B'),
(7, 7, 7, 'S24', 'Second_makeup', 'C+'),
(8, 8, 8, 'S24R1', 'Normal', 'A+'),
(9, 9, 9, 'S24R2', 'Normal', 'FF'),
(10, 10, 10, 'S24', 'First_makeup', 'B-');


-- Adding 10 records to the Course_Semester table
INSERT INTO Course_Semester (course_id, semester_code) VALUES
(1, 'W23'),
(2, 'S23'),
(3, 'S23R1'),
(4, 'S23R2'),
(5, 'W23'),
(6, 'W24'),
(7, 'S24'),
(8, 'S24R1'),
(9, 'S24R2'),
(10, 'S24');

-- Adding 10 records to the Slot table
INSERT INTO Slot (day, time, location, course_id, instructor_id) VALUES
( 'Monday', 'First', 'Room A', 1, 1),
( 'Tuesday', 'First', 'Room B', 2, 2),
( 'Wednesday', 'Third', 'Room C', 3, 3),
( 'Thursday', 'Fifth', 'Room D', 4, 4),
( 'Saturday', 'Second', 'Room E', 5, 5),
( 'Monday', 'Fourth', 'Room F', 6, 6),
( 'Tuesday', 'Second', 'Room G', 7, 7),
( 'Wednesday', 'Fifth', 'Room H', 8, 8),
( 'Thursday', 'First', 'Room I', 9, 9),
( 'Sunday', 'Fourth', 'Room J', 10, 10);


-- Adding 10 records to the Graduation_Plan table
INSERT INTO Graduation_Plan (semester_code, semester_credit_hours, expected_grad_date, student_id, advisor_id) VALUES
( 'W23', 90,    '2024-01-31' ,   1, 1),
( 'S23', 85,    '2025-01-31'  ,     2, 2),
( 'S23R1', 75,  '2025-06-30' ,  3, 3),
( 'S23R2', 95,  '2024-06-30' , 4, 4),
( 'W23', 80,    '2026-01-31'   ,  5, 5),
( 'W24', 88,    '2024-06-30'   ,    6, 6),
( 'S24', 78,    '2024-06-30'    ,  7, 7),
( 'S24R1', 92,  '2025-01-31'  , 8, 8),
( 'S24R2', 87,  '2024-06-30'    ,  9, 9),
( 'S24', 89,    '2025-01-31'    ,    10, 10);

-- Adding 10 records to the GradPlan_Course table
INSERT INTO GradPlan_Course(plan_id, semester_code, course_id) VALUES
(1, 'W23', 1),
(2, 'S23', 2),
(3, 'S23R1', 3),
(4, 'S23R2', 4),
(5, 'W23', 5),
(6, 'W24', 6),
(7, 'S24', 7),
(8, 'S24R1', 8),
(9, 'S24R2', 9),
(10, 'S24', 10);

-- Adding 10 records to the Request table
INSERT INTO Request (type, comment, status, credit_hours, course_id, student_id, advisor_id) VALUES 
( 'course', 'Request for additional course', 'pending', null, 1, 1, 2),
( 'course', 'Need to change course', 'approved', null, 2, 2, 2),
( 'credit_hours', 'Request for extra credit hours', 'pending', 3, null, 3, 3),
( 'credit_hours', 'Request for reduced credit hours', 'approved', 1, null, 4, 5),
( 'course', 'Request for special course', 'rejected', null, 5, 5, 5),
( 'credit_hours', 'Request for extra credit hours', 'pending', 4, null, 6, 7),
( 'course', 'Request for course withdrawal', 'approved', null, 7, 7, 7),
( 'course', 'Request for course addition', 'rejected', null, 8, 8, 8),
( 'credit_hours', 'Request for reduced credit hours', 'approved', 2, null, 9, 8),
( 'course', 'Request for course substitution', 'pending', null, 10, 10, 10);

-- Adding 10 records to the MakeUp_Exam table
INSERT INTO MakeUp_Exam (date, type, course_id) VALUES
('2023-02-10', 'First MakeUp', 1),
('2023-02-15', 'First MakeUp', 2),
('2023-02-05', 'First MakeUp', 3),
('2023-02-25', 'First MakeUp', 4),
('2023-02-05', 'First MakeUp', 5),
('2024-09-10', 'Second MakeUp', 6),
('2024-09-20', 'Second MakeUp', 7),
('2024-09-05', 'Second MakeUp', 8),
('2024-09-10', 'Second MakeUp', 9),
( '2024-09-15', 'Second MakeUp', 10);

-- Adding 10 records to the Exam_Student table
INSERT INTO Exam_Student(exam_id, student_id,course_id) VALUES (1, 1, 1);
INSERT INTO Exam_Student(exam_id, student_id,course_id) VALUES (1, 2, 2);
INSERT INTO Exam_Student(exam_id, student_id,course_id) VALUES (1, 3, 3);
INSERT INTO Exam_Student(exam_id, student_id,course_id) VALUES (2, 2, 4);
INSERT INTO Exam_Student(exam_id, student_id,course_id) VALUES (2, 3, 5);
INSERT INTO Exam_Student(exam_id, student_id,course_id) VALUES (2, 4, 6);
INSERT INTO Exam_Student(exam_id, student_id,course_id) VALUES (3, 3, 7);
INSERT INTO Exam_Student(exam_id, student_id,course_id) VALUES (3, 4, 8);
INSERT INTO Exam_Student(exam_id, student_id,course_id) VALUES (3, 5, 9);
INSERT INTO Exam_Student(exam_id, student_id,course_id) VALUES (4, 4, 10);

-- Adding 10 records to the Payment table
INSERT INTO Payment (amount, start_date,n_installments, status, fund_percentage, student_id, semester_code, deadline)  VALUES
( 500, '2023-11-22', 1, 'notPaid', 50.00, 1, 'W23', '2023-12-22'),
( 700, '2023-11-23', 1, 'notPaid', 60.00, 2, 'S23', '2023-12-23'),
( 600, '2023-11-24', 4, 'notPaid', 40.00, 3, 'S23R1', '2024-03-24'),
( 800, '2023-11-25', 1, 'notPaid', 70.00, 4, 'S23R2', '2023-12-25'),
( 550, '2023-11-26', 5, 'notPaid', 45.00, 5, 'W23', '2024-04-26'),
( 900, '2023-11-27', 1, 'notPaid', 80.00, 6, 'W24', '2023-12-27'),
( 750, '2023-10-28', 2, 'Paid', 65.00, 7, 'S24', '2023-12-28'),
( 620, '2023-08-29', 4, 'Paid', 55.00, 8, 'S24R1', '2023-12-29'),
( 720, '2023-11-30', 2, 'notPaid', 75.00, 9, 'S24R2', '2024-01-30'),
( 580, '2023-11-30', 1, 'Paid', 47.00, 10, 'S24', '2023-12-31');



-- Adding 10 records to the Installment table
INSERT INTO Installment (payment_id, start_date, amount, status, deadline) VALUES
(1, '2023-11-22', 50, 'notPaid','2023-12-22'),
(2, '2023-11-23', 70, 'notPaid','2023-12-23'),
(3, '2023-12-24', 60, 'notPaid','2024-01-24'),
( 4,'2023-11-25', 80, 'notPaid','2023-12-25'),
(5, '2024-2-26', 55, 'notPaid','2024-3-26'),
( 6,'2023-11-27', 90, 'notPaid','2023-12-06'),
(7, '2023-10-28', 75, 'Paid','2023-11-28'),
( 8,'2023-11-28', 62, 'Paid','2023-12-28'),
( 9,'2023-12-30', 72, 'notPaid','2024-01-30'),
( 10,'2023-11-30', 58, 'Paid','2023-12-30');


GO
CREATE PROC DropAllTables
AS
DROP TABLE Installment;
DROP TABLE Payment;
DROP TABLE Exam_Student;
DROP TABLE MakeUP_Exam;
DROP TABLE Request;
DROP TABLE GradPlan_Course;
DROP TABLE Graduation_Plan;
DROP TABLE Slot;
DROP TABLE Course_Semester;
DROP TABLE Semester;
DROP TABLE Student_Instructor_Course_Take;
DROP TABLE Instructor_Course;
DROP TABLE Instructor;
DROP TABLE PreqCourse_Course;
DROP TABLE Course;
DROP TABLE Student_Phone;
DROP TABLE Student;
DROP TABLE Advisor;

EXEC DropAllTables

GO;

GO
CREATE PROC clearAllTables

AS
TRUNCATE TABLE Student_Phone;
TRUNCATE TABLE PreqCourse_Course;
TRUNCATE TABLE Instructor_Course;
TRUNCATE TABLE Student_Instructor_Course_Take;
TRUNCATE TABLE Course_Semester;
TRUNCATE TABLE Slot;
TRUNCATE TABLE GradPlan_Course;
TRUNCATE TABLE Request;
TRUNCATE TABLE Exam_Student;
TRUNCATE TABLE Installment;

DELETE FROM Payment;
DELETE FROM MakeUP_Exam;
DELETE FROM Course;
DELETE FROM Semester;
DELETE FROM Graduation_Plan;
DELETE FROM Instructor;
DELETE FROM Student;
DELETE FROM Advisor;

EXEC clearAllTables
GO;

GO
CREATE VIEW view_Students --A
AS 
SELECT * FROM Student 

GO;

GO
CREATE VIEW view_Course_prerequisites --B
AS
SELECT * FROM PreqCourse_course 
GO;


GO
Create view  Instructors_AssignedCourses --C
AS 
select  C.name As Course_name,I.*
from Instructor I 
inner join Instructor_Course IC on  I.instructor_id=IC.instructor_id 
inner join Course C ON IC.course_id=C.course_id 
GO;


GO
Create view Student_Payment --D
AS 
Select S.f_name,S.l_name,P.* from Payment P inner join Student S on P.student_id = S.student_id 
GO;


GO
CREATE VIEW Courses_Slots_Instructor --E
AS 
    SELECT  c.course_id, c.name as Course_name,s.slot_id,s.day,s.time,s.location,i.name as Instructor_name
    FROM Course c INNER JOIN  Slot s ON c.course_id = s.course_id 
    INNER JOIN Instructor i on s.instructor_id = i.instructor_id
GO;

GO 
CREATE VIEW Courses_MakeupExams --F
AS 
SELECT c.name,c.semester,m.*
FROM Course c INNER JOIN MakeUp_Exam m ON c.course_id=m.course_id 
GO;

GO
CREATE VIEW Students_Courses_transcript --G
AS
SELECT SICT.student_id, S.f_name AS 'first_name', S.l_name AS 'last_name', C.course_id, C.name AS 'course_name', SICT.exam_type, SICT.grade, SICT.semester_code, SICT.instructor_id, I.name AS 'instructor_name'
FROM Student_Instructor_Course_Take SICT
    INNER JOIN Student S ON SICT.student_id = S.student_id
    INNER JOIN Course C ON SICT.course_id = C.course_id
    INNER JOIN Instructor I ON SICT.instructor_id = I.instructor_id
GO;

GO
CREATE VIEW Semster_offered_Courses --H
AS
SELECT C.course_id, C.name, C.semester
FROM Course C
GO;

GO
CREATE VIEW Advisors_Graduation_Plan --I
AS
SELECT GP.*, A.name AS 'advisor_name'
FROM Graduation_Plan GP
    INNER JOIN Advisor A ON A.advisor_id = GP.advisor_id
GO;

Go 
CREATE PROC Procedures_StudentRegistration --A
@first_name varchar (40),
@last_name varchar (40),
@password varchar (40),
@faculty varchar (40),
@email varchar (40),
@major varchar (40),
@Semester int,
@Student_id int OUTPUT
AS
INSERT INTO Student(f_name,l_name, password, faculty, email, major, semester) VALUES (@first_name, @last_name, @password, @faculty, @email, @major, @Semester);
SELECT @Student_id = Student.student_id
FROM Student
WHERE @first_name =f_name AND
@last_name = l_name AND
@password = password AND
@faculty = faculty AND
@email = email AND 
@major = major AND 
@Semester = semester
GO;


GO
CREATE PROC Procedures_AdvisorRegistration --B
@advisor_name varchar(40),
@password varchar(40), 
@email varchar(40), 
@office varchar(40),
@Advisor_id int OUTPUT
AS
INSERT INTO Advisor (name,email,office,password) VALUES (@advisor_name,@email,@office,@password)
SELECT @Advisor_id=advisor_id 
FROM Advisor 
WHERE @advisor_name=name AND @password=password AND @office=office AND @email=email
GO;


 GO 
CREATE PROC Procedures_AdminListStudents --C
AS
SELECT *
FROM Student
GO;

GO
CREATE PROC Procedures_AdminListAdvisors --D
As
Select * from Advisor
GO;

GO
CREATE PROC  AdminListStudentsWithAdvisors --E
AS 
SELECT student_id ,advisor_id
FROM Student
GO;

GO
CREATE PROC AdminAddingSemester --F
@start_date DATE,
@end_date DATE,
@semester_code INT
AS
INSERT INTO Semester VALUES(@semester_code,@start_date,@end_date);
GO;


GO
CREATE PROC Procedures_AdminAddingCourse --G
@major varchar (40),
@semester int,
@credit_hours int, 
@course_name varchar (40), 
@offered bit
As
INSERT INTO Course (major,semester,credit_hours,name,is_offered )
VALUES(@major,@semester,@credit_hours,@course_name,@offered)
GO;


GO
CREATE PROC Procedures_AdminLinkInstructor --H
 @InstructorId int, 
 @courseId int, 
 @slotID int
AS
Update Slot 
set instructor_id=@InstructorId 
where slot_id= @slotID

Update Slot 
set course_id=@courseId 
where slot_id= @slotID
 GO;

GO
CREATE PROC Procedures_AdminLinkStudent --I
@instructor_Id INT,
@student_ID INT,
@course_ID INT,
@semester_code VARCHAR(40)
AS
INSERT INTO Student_Instructor_Course_Take (instructor_id ,student_id, course_id, semester_code)
VALUES(@instructor_Id, @student_ID, @course_ID, @semester_code)
GO;


GO
Create PROC  Procedures_AdminLinkStudentToAdvisor --J
@studentID int,
@advisorID int
AS 
Update Student Set advisor_id=@advisorID where student_id=@studentID;	
GO;



GO
CREATE PROC Procedures_AdminAddExam --K
@Type varchar (40), 
@date datetime, 
@courseID int
AS
IF NOT EXISTS( SELECT type,date,course_id  FROM MakeUp_Exam WHERE type=@Type AND date=@date AND  course_id= @courseID)
BEGIN 
INSERT INTO MakeUp_Exam (type,date,course_id)
VALUES(@Type,@date,@courseID)
END 
ELSE 
PRINT('EXAM ALREADY ADDED ')
GO;

GO
CREATE PROCEDURE Procedures_AdminIssueInstallment --L
    @paymentID INT
AS
BEGIN
    DECLARE @installmentCount INT
    DECLARE @installmentAmount INT
    DECLARE @deadline DATETIME
    DECLARE @startDate DATETIME

    SELECT @installmentCount = n_installments,
           @installmentAmount = amount / n_installments,
           @deadline = deadline,
           @startDate = start_date
    FROM Payment
    WHERE payment_id = @paymentID

    DECLARE @month INT = 1

    WHILE @month <= @installmentCount
    BEGIN
        DECLARE @deadline2 DATETIME;
        SET @deadline2 = DATEADD(MONTH, @month - 1, @startDate);
        UPDATE Installment
        SET deadline = @deadline2, amount = @installmentAmount, status = 'notPaid', start_date = @startDate
        Where payment_id = @paymentID

        SET @month = @month + 1
    END
END
GO;



GO 
Create PROC Procedures_AdminDeleteCourse --M
@courseID int
AS 
Delete from PreqCourse_course where prerequisite_course_id=@courseID
Delete from Slot where course_id=@courseID
Delete from Course where course_id=@courseID 
GO;




GO
 CREATE PROCEDURE Procedure_AdminUpdateStudentStatus --N
 @StudentID INT
 AS
    IF NOT EXISTS (
        SELECT *
        FROM Student INNER JOIN Payment AS p ON Student.student_id = p.student_id
                    INNER JOIN Installment ON p.payment_id = Installment.payment_id
        WHERE Student.student_id = @StudentID AND Installment.status = 'NotPaid'
                                                AND Installment.deadline < CURRENT_TIMESTAMP
    )
    BEGIN
    UPDATE Student
    SET financial_status = 1
    WHERE student_id = @StudentID
    END

    ELSE
    BEGIN  
    UPDATE Student
    SET financial_status = 0
    WHERE student_id = @StudentID
    END
    GO;
    

GO
CREATE VIEW all_Pending_Requests --O
AS 
SELECT R.*,S.f_name, S.l_name, A.name As advisor_name
FROM Request R
    INNER JOIN Student S on R.student_id = S.student_id 
    INNER JOIN Advisor A on R.advisor_id = A.advisor_id
Where R.status = 'pending';
GO;


GO 
CREATE PROC Procedures_AdminDeleteSlots --P
@current_semester varchar (40)
AS 
Delete from Slot where  course_id IN (
Select C.course_id from Course C  inner join Course_Semester CS on  CS.course_id=C.course_id
where  CS.semester_code <> @current_semester )
GO;


GO
CREATE FUNCTION FN_AdvisorLogin  --Q
(@ID int, @password varchar (40)) 
RETURNS BIT 
AS 
BEGIN
DECLARE @Success BIT 
IF EXISTS (SELECT * FROM Advisor WHERE   Advisor.advisor_id = @ID and  Advisor.password = @password)
    Set @Success = 1
ELSE 
    Set @Success = 0

RETURN @Success
END 
GO;


GO        
CREATE PROCEDURE Procedures_AdvisorCreateGP --R
@Semester_code varchar (40), 
@expected_graduation_date date,
@sem_credit_hours int, 
@advisor_id int, 
@student_id int
AS
BEGIN

    IF EXISTS (SELECT 1 FROM Graduation_Plan WHERE student_id = @student_id)
    BEGIN
        PRINT('A graduation plan already exists for the student.');
       
    END
    DECLARE @acquired_hours int;
    SELECT @acquired_hours = acquired_hours FROM Student WHERE student_id = @student_id;

    IF @acquired_hours <= 157
    BEGIN
        PRINT('The student must have acquired hours greater than 157 to create a graduation plan.');
        RETURN;
    END
    INSERT INTO Graduation_Plan (semester_code, semester_credit_hours, expected_grad_date, advisor_id, student_id)
    VALUES (@semester_code, @sem_credit_hours, @expected_graduation_date, @advisor_id, @student_id);
END
GO; 



GO 
CREATE PROC Procedures_AdvisorAddCourseGP --S
@student_id int, 
@Semester_code varchar (40), 
@course_name varchar (40)
AS
DECLARE @course_id INT
SELECT @course_id = course_id
FROM Course
Where @course_name = name

DECLARE @plan_id INT
SELECT @plan_id = plan_id
FROM Graduation_Plan
WHERE @student_id = student_id

UPDATE GradPlan_Course
SET course_id = @course_id
WHERE semester_code = @Semester_code and @plan_id = plan_id
GO;


GO 
CREATE PROC Procedures_AdvisorUpdateGP --T
@expected_grad_date varchar (40),
@studentID int
AS 
UPDATE Graduation_Plan set expected_grad_date = @expected_grad_date where student_id=@studentID 
GO;


GO
CREATE PROCEDURE Procedures_AdvisorDeleteFromGP --U
    @studentID INT,
    @semester_code VARCHAR(40),
    @course_ID INT
AS
    DELETE FROM GradPlan_Course
    WHERE plan_id IN (
        SELECT plan_id
        FROM Graduation_Plan
        WHERE student_id = @studentID
        AND semester_code = @semester_code
    )
    AND semester_code = @semester_code
    AND course_id = @course_ID;
GO ;

GO
CREATE FUNCTION FN_Advisors_Requests --V
(@advisorID int)
RETURNS TABLE
AS
RETURN
(
 SELECT *
 FROM Request
 WHERE @advisorID = Request.advisor_id
)
GO;



GO
CREATE PROC Procedures_AdvisorApproveRejectCHRequest --W
@RequestID int, 
@Current_semester_code varchar (40)
AS
DECLARE @student_id int, @gpa DECIMAL, @credit_hours INT, @payment_id INT, @date DATETIME, @type VARCHAR(40);

SELECT @student_id = Student.student_id, @gpa = Student.gpa, @credit_hours = Request.credit_hours, @type = Request.type
FROM Request
	INNER JOIN Student on Request.student_id = Student.student_id
WHERE Request.request_id = @RequestID

SELECT @payment_id = payment_id
FROM Payment
WHERE @student_id = Payment.student_id

SELECT @date = deadline 
FROM Installment
WHERE payment_id = @payment_id

IF @gpa <= 3.7 AND @credit_hours + 3 <= 34 AND @type = 'Request for extra credit hours'
BEGIN 
	UPDATE Request
    SET status = 'approved'
    WHERE Request.request_id = @RequestID

    UPDATE Payment
    SET amount = amount + 1000
    WHERE @student_id = Payment.student_id AND Payment.semester_code = @Current_semester_code

    UPDATE Installment
    SET amount = amount + 1000
    WHERE payment_id = @payment_id AND start_date = @date
    
END
ELSE
BEGIN
	UPDATE Request
    SET status = 'rejected'
    WHERE Request.request_id = @RequestID
END
GO;


GO
CREATE PROC Procedures_AdvisorViewAssignedStudents --X
@AdvisorID int ,
@major varchar (40)
AS 
Select s.student_id AS Student_id,CONCAT(s.f_name, ' ', s.l_name) AS Student_name , s.major AS Student_major,c.name As Course_name from Student s 
inner join  Student_Instructor_Course_Take  sct on s.student_id=sct.student_id
inner join Course c on sct.course_id=c.course_id 
where s.advisor_id=@AdvisorID AND s.major=@major 
GO;



GO
CREATE PROC Procedures_AdvisorApproveRejectCourseRequest --Y
@RequestID int, 
@studentID int,
@advisorID int
AS
    DECLARE @Hours_per_student INT;
    DECLARE @Prerequisites INT;
     -- Get the student's assigned hours
    SELECT @Hours_per_student = assigned_hours
    FROM Student
    WHERE student_id = @studentID;
     -- Check if all requested course prerequisites are taken
        --count number of preq not taken by student
    SELECT @Prerequisites = COUNT(*)
    FROM PreqCourse_course
    WHERE prerequisite_course_id IN (
        -- get preq id of courses assosiated with the requested course from the preruisities table 
        SELECT prerequisite_course_id
        FROM PreqCourse_course
        WHERE course_id = (
           -- course id of selected course
            SELECT course_id
            FROM Request
            WHERE request_id = @RequestID
        )
    )
    -- ensure student has taken all preq
    AND PreqCourse_course.course_id NOT IN (
        SELECT course_id
        FROM Student_Instructor_Course_Take
        WHERE student_id = @studentID
    )
    
    -- Update the status of the course request based on conditions
    IF (@Prerequisites = 0 AND @Hours_per_student >= (
          SELECT credit_hours
          FROM Course
          WHERE course_id = (
              SELECT course_id
              FROM Request
              WHERE request_id = @RequestID
          )
        )
    )
    BEGIN
        
        UPDATE Request
        SET status = 'Approved'
        WHERE request_id = @RequestID;
    END
    ELSE
    BEGIN
        
        UPDATE Request
        SET status = 'Rejected'
        WHERE request_id = @RequestID;
    END
GO;

GO
CREATE PROC Procedures_AdvisorViewPendingRequests --Z
@Advisor_ID int
AS
SELECT Request.*
FROM Request
Where advisor_id = @Advisor_ID AND status = 'pending'
GO;


GO
CREATE FUNCTION FN_StudentLogin (@StudentID int, @password varchar (40) ) --AA
RETURNS BIT 
AS 
BEGIN
DECLARE @Success1 BIT 
IF EXISTS (SELECT * FROM Student WHERE  student_id = @StudentID and password= @password)
    Set @Success1 = 1
ELSE 
    Set @Success1 = 0

RETURN @Success1 
END 
GO;



GO
Create PROC Procedures_StudentaddMobile --BB
@StudentID int,
@mobile_number varchar (40)
AS 
if @StudentID in (select student_id from Student)
BEGIN
INSERT INTO Student_Phone VALUES (@StudentID,@mobile_number)
END 
GO;
EXEC Procedures_StudentaddMobile 11,'01027556611'

 

GO
Create Function FN_SemsterAvailableCourses --CC
(@semester_code varchar(40)) 
Returns Table 
AS 
Return(Select * from Course_Semester where semester_code=@semester_code)
GO;


GO
CREATE PROC Procedures_StudentSendingCourseRequest --DD
    @StudentID int, 
    @courseID int, 
    @type varchar (40),  
    @comment varchar (40) 

    AS
    INSERT INTO Request(student_id,course_id,type,comment)
    VALUES (@StudentID,@courseID,@type,@comment)
GO;

    


GO
CREATE PROC Procedures_StudentSendingCHRequest --EE
@Student_ID int, 
@credit_hours int, 
@type varchar (40), 
@comment varchar (40)
AS
INSERT INTO Request(student_id, credit_hours, type, comment)
VALUES(@Student_ID,@credit_hours,@type,@comment);
GO;


GO
Create Function FN_StudentViewGP --FF
(@student_ID int)
Returns Table 
AS
Return(Select S.student_id,CONCAT(S.f_name, ' ' , S.l_name)AS 'Student_name',
GC.plan_id AS 'Graduation plan',GC.course_id,C.name AS 'Course Name '
,GC.semester_code ,G.expected_grad_date ,G.semester_credit_hours,G.advisor_id

from Student S
inner join Graduation_Plan G on S.student_id = G.student_id
inner join GradPlan_Course GC on G.semester_code=GC.semester_code
inner join Course C on GC.course_id=C.course_id
 where S.student_id=@student_ID
)
GO;



GO 
CREATE FUNCTION FN_StudentUpcoming_installment --GG
(@student_id int)
RETURNS DATE
AS 
BEGIN
DECLARE @return_Date DATE

SELECT TOP 1 @return_Date = deadline
FROM Payment
Where status = 'notPaid' and Payment.student_id = @student_id
ORDER BY Payment.n_installments ASC

RETURN @return_Date
END
GO;


GO
CREATE FUNCTION FN_StudentViewSlot (@CourseID int,@InstructorID int) --HH
RETURNS TABLE 
AS 
RETURN 
SELECT s.slot_id, s.location, s.time, s.day , c.name AS Course_Name , i.name AS Instructor_Name
FROM Slot s INNER JOIN Course c ON (s.course_id = c.course_id) INNER JOIN Instructor i ON (s.instructor_id = i.instructor_id)
WHERE c.course_id = @CourseID AND i.instructor_id = @InstructorID
GO;


GO 
CREATE PROC Procedures_StudentRegisterFirstMakeup --II
@StudentID int, 
@courseID int, 
@studentCurrent_semester varchar(40)
AS
if @studentCurrent_semester in (select CS.semester_code 
from Course_Semester CS INNER JOIN  Student_Instructor_Course_Take sct on cs.course_id=sct.course_id  where sct.student_id=@StudentID AND sct.grade IN ('F','FF','FA',NULL))
AND @StudentID IN (select ES.student_id from  Exam_Student ES 
WHERE exam_id = ALL ( SELECT ME.exam_id FROM  MakeUp_Exam ME WHERE type='NORMAL'))
BEGIN 
insert into Exam_Student(student_id,course_id)values(@StudentID,@courseID) 
insert into Student_Instructor_Course_Take(student_id,course_id)values(@StudentID,@courseID)
END
GO;


GO
CREATE FUNCTION  FN_StudentCheckSMEligiability (@CourseID int,@StudentID int) --JJ
   
    RETURNS BIT
    AS
    BEGIN 

    DECLARE @eligible BIT
    IF EXISTS (
        SELECT *
        FROM Student_Instructor_Course_Take
        WHERE student_id = @StudentID AND course_id = @CourseID 
        AND grade IN ('F','FF') 
        AND exam_type = 'First_makeup'  
    )
    BEGIN
        
        -- Check if the student has a maximum of two failed courses per all odd or even semesters
        DECLARE @type VARCHAR(40)
        DECLARE @failedcount INT
       
         SET @type = CASE
            WHEN LEFT(@CurrentSemester, 1) = 'W' THEN 'W'
            WHEN LEFT(@CurrentSemester, 1) = 'S'  THEN 'S'
            WHEN LEFT(@CurrentSemester, 1) = 'S' AND RIGHT(@CurrentSemester, 2) = 'R1' THEN 'R1'
            WHEN LEFT(@CurrentSemester, 1) = 'S' AND RIGHT(@CurrentSemester, 2) = 'R2' THEN 'R2'
            ELSE ''
        END

        -- Counting the number of failed courses in the corresponding semesters
        SELECT @failedcount = COUNT(DISTINCT c.course_id)
        FROM Student_Instructor_Course_Take s1
        INNER JOIN Course c ON s1.course_id = c.course_id
        INNER JOIN Semester s2 ON s1.semester_code = s2.semester_code
        WHERE s1.student_id = @StudentID AND (s1.grade = 'F' or s1.grade='FF')
        AND (( s2.semester_code LIKE @type + '%') OR (s2.semester_code LIKE '%' + @type))

        IF @failedcount <= 2
            SET @eligible = 1 
        ELSE
            SET @eligible = 0 
    END
    ELSE
    BEGIN
        SET @eligible = 0 
       
    END
    RETURN @eligible
    END 
GO;


GO
CREATE PROCEDURE Procedures_StudentRegisterSecondMakeup --KK
    @StudentID INT,
    @CourseID INT,
    @CurrentSemester VARCHAR(40)
    AS


    DECLARE @eligible BIT
    IF EXISTS (
        SELECT *
        FROM Student_Instructor_Course_Take
        WHERE student_id = @StudentID AND course_id = @CourseID 
        AND grade IN ('F','FF') 
        AND exam_type = 'First_makeup'  
    )
    BEGIN
        
        -- Check if the student has a maximum of two failed courses per all odd or even semesters
        DECLARE @type VARCHAR(40)
        DECLARE @failedcount INT
       
        SET @type = CASE
            WHEN LEFT(@CurrentSemester, 1) = 'W' THEN 'W'
            WHEN LEFT(@CurrentSemester, 1) = 'S'  THEN 'S'
            WHEN LEFT(@CurrentSemester, 1) = 'S' AND RIGHT(@CurrentSemester, 2) = 'R1' THEN 'R1'
            WHEN LEFT(@CurrentSemester, 1) = 'S' AND RIGHT(@CurrentSemester, 2) = 'R2' THEN 'R2'
            ELSE ''
        END

        -- Counting the number of failed courses in the corresponding semesters
        SELECT @failedcount = COUNT(DISTINCT c.course_id)
        FROM Student_Instructor_Course_Take s1
        INNER JOIN Course c ON s1.course_id = c.course_id
        INNER JOIN Semester s2 ON s1.semester_code = s2.semester_code
        WHERE s1.student_id = @StudentID AND (s1.grade = 'F' or s1.grade='FF') 
        AND (( s2.semester_code LIKE @type + '%') OR (s2.semester_code LIKE '%' + @type))

        IF @failedcount <= 2
            SET @eligible = 1 
        ELSE
            SET @eligible = 0 
    END
    ELSE
    BEGIN
        SET @eligible = 0 
        PRINT(' You are not eligible to register to a second makeup')
    END

    
    IF @eligible = 1
    BEGIN
        INSERT INTO Student_Instructor_Course_Take (student_id, course_id,  semester_code, exam_type)
        VALUES (@StudentID, @CourseID, @CurrentSemester, 'Second_makeup')
        
        UPDATE   MakeUp_Exam 
        set date = CURRENT_TIMESTAMP,type='Second MakeUp'
        WHERE course_id=@CourseID

    END 
    GO;
   

GO 
CREATE PROC Procedures_ViewRequiredCourses --LL
    @StudentID INT,
    @Current_semester_code VARCHAR(40)
AS
    SELECT C.* --Unattended Courses
    FROM Course C
    INNER JOIN Course_Semester CS ON C.course_id = CS.course_id
    INNER JOIN Student_Instructor_Course_Take SICT on SICT.student_id = @StudentID
    WHERE (CAST(SUBSTRING(CS.semester_code,2,2) AS INT) < CAST(SUBSTRING(@Current_semester_code,2,2)AS INT)) OR (SICT.grade = 'FA')

    UNION

    SELECT C1.* --Failed Courses
    FROM Course C1
    INNER JOIN MakeUp_Exam M ON M.course_id = C1.course_id
    INNER JOIN Exam_Student E ON M.exam_id = E.exam_id
    INNER JOIN Student_Instructor_Course_Take SICT on SICT.student_id = @StudentID
    WHERE (M.type = 'First_MakeUp' AND E.student_id = @StudentID) OR (SICT.grade IN ('F','FF') );
GO;


GO

Create Proc Procedures_ViewOptionalCourse --MM
@StudentID int,
@Current_semester_code Varchar(40)
AS 
Select C.course_id,C.name,C.is_offered,C.credit_hours,C.semester from Course C 
INNER JOIN Course_Semester CS on C.course_id=CS.course_id 
INNER JOIN Student_Instructor_Course_Take SCT ON SCT.course_id=C.course_id
where  CS.semester_code=@Current_semester_code AND SCT.student_id=@StudentID AND (CS.semester_code=SCT.semester_code OR CS.semester_code <> SCT.semester_code)
GO;


GO
CREATE PROCEDURE Procedures_ViewMS --NN
@StudentID INT
AS
SELECT Course.course_id, Course.name, Course.major, Course.credit_hours, Course.semester
    FROM Course  INNER JOIN GradPlan_Course  ON Course.course_id = GradPlan_Course.course_id INNER JOIN Graduation_Plan  ON GradPlan_Course.plan_id = Graduation_Plan.plan_id AND GradPlan_Course.semester_code = Graduation_Plan.semester_code
    WHERE Graduation_Plan.student_id = @StudentID
    AND GradPlan_Course.course_id NOT IN (
        SELECT Student_Instructor_Course_Take.course_id
        FROM Student_Instructor_Course_Take 
        WHERE Student_Instructor_Course_Take.student_id = @StudentID
    );
    DROP PROC Procedures_ViewMS
GO
CREATE PROC Procedures_ChooseInstructor --OO
@Student_ID int, 
@Instructor_ID int, 
@Course_ID int
AS
DECLARE @semester VARCHAR(40);
SELECT @semester = CS.semester_code
FROM Course_Semester CS
WHERE CS.course_id = @Course_ID

INSERT INTO Student_Instructor_Course_Take (student_id,course_id,instructor_id, semester_code)
VALUES(@Student_ID,@Course_ID,@Instructor_ID, @semester);
GO;

--Points to consider functions :

GO 
CREATE Function  Update_student_status   --(Points to Consider) Updating the status of the student
 (@StudentID INT)
 returns BIT
 AS
 BEGIN

 Declare @financial_status bit
    IF NOT EXISTS (
        SELECT *
        FROM Student INNER JOIN Payment AS p ON Student.student_id = p.student_id
                    INNER JOIN Installment ON p.payment_id = Installment.payment_id
        WHERE Student.student_id = @StudentID AND Installment.status = 'NotPaid'
                                                AND Installment.deadline < CURRENT_TIMESTAMP
    )
    BEGIN
    
    SET @financial_status = 1
    END

    ELSE

    BEGIN  
    SET @financial_status = 0
    END
    return @financial_status
    END
 GO;


CREATE FUNCTION deadline --Extra function for deadline
(@start_date DATETIME)
RETURNS DATETIME
AS
BEGIN
DECLARE @result_deadline DATETIME
SET @result_deadline = DATEADD(MONTH, 2, @start_date)
RETURN @result_deadline
END
GO;

GO
CREATE FUNCTION probation --Milestone 1 (Points to consider) for checking if student under probation or not                                                                                                                                                               
(@gpa DECIMAL, @Current_semester_credit_hours INT)
RETURNS INT
AS
BEGIN
DECLARE @new_Credit_hours INT
IF @gpa>3.7
Begin 
SET @new_Credit_hours = (@Current_semester_credit_hours * 75/100)
END
ELSE
BEGIN
RETURN @Current_semester_credit_hours
END
RETURN @new_Credit_hours
END
GO;




--Executions of the whole milestone :

EXEC CreateAllTables -- 2.1.2
EXEC DropAllTables -- 2.1.3
EXEC clearAllTables -- 2.1.4

SELECT * FROM view_Students  --2.2.A
SELECT * FROM view_Course_prerequisites  --2.2.B
select* from Instructors_AssignedCourses  --2.2.C
Select* from Student_Payment  --2.2.D
Select* from Courses_Slots_Instructor  --2.2.E
Select* from Courses_MakeupExams  --2.2.F
Select* from Students_Courses_transcript  --2.2.G
Select* from Semster_offered_Courses  --2.2.H
Select* from Advisors_Graduation_Plan  --2.2.I


DECLARE @output int   --2.3.A
EXEC Procedures_StudentRegistration 'MOHAMED','WALID','KKK','ENGINEERING','HFUIHF','MET',5,@output
print(@output)

DECLARE @output int   --2.3.B
EXEC Procedures_AdvisorRegistration 'MOHAMED','WALID','KKK','ENGINEERING',@output
print(@output)

Exec Procedures_AdminListStudents  --2.3.C
EXEC Procedures_AdminListAdvisors  --2.3.D
EXEC AdminListStudentsWithAdvisors  --2.3.E
EXEC AdminAddingSemester 'W24','2024-02-15','2024-06-15'  --2.3.F
EXEC AdminAddingSemester 'MET',3,3,'cs',1  --2.3.G
Exec Procedures_AdminLinkInstructor 1,2,3  --2.3.H
EXEC Procedures_AdminLinkStudent 1, 2, 3, 'W23';  --2.3.I
EXEC Procedures_AdminLinkStudentToAdvisor 1,2   --2.3.J
EXEC Procedures_AdminAddExam  'First MakeUp','2023-05-10',  3  --2.3.K
EXEC Procedures_AdminIssueInstallment 1  --2.3.L
EXEC Procedures_AdminDeleteCourse 4  --2.3.M
EXEC Procedure_AdminUpdateStudentStatus  2  --2.3.N
SELECT * FROM all_Pending_Requests  --2.3.O
Exec Procedures_AdminDeleteSlots 'W24'  --2.3.P

DECLARE @ID int = 1     --2.3.Q
DECLARE @password varchar(40) = 'password1'
DECLARE @Success bit
SELECT @Success = dbo.FN_AdvisorLogin(@ID, @password)
IF @Success = 1
    PRINT 'Login successful.';
ELSE
    PRINT 'Login failed.'; 

EXEC  Procedures_AdvisorCreateGP 's23', '2023-11-11',90,2, 9  --2.3.R
EXEC Procedures_AdvisorAddCourseGP 1, 'W23', 'CSEN 3'  --2.3.S
Exec Procedures_AdvisorUpdateGP '2026-01-31',1  --2.3.T
EXEC Procedures_AdvisorDeleteFromGP 1, 'W23', 1  --2.3.U
SELECT * FROM dbo.FN_Advisors_Requests(5)  --2.3.V

EXEC Procedures_AdvisorApproveRejectCHRequest 3, 'W23'--2.3.W
select * from Request
select * from Payment
select * from Installment
select * from Student


Exec Procedures_AdvisorViewAssignedStudents 3,'CS'   --2.3.X
EXEC Procedures_AdvisorApproveRejectCourseRequest 2,3,4   --2.3.Y
EXEC Procedures_AdvisorViewPendingRequests 2  --2.3.Z


DECLARE @StudentID int = 1    --2.3.AA
DECLARE @password varchar(40) = 'password123'
DECLARE @Success bit
SELECT @Success = dbo.FN_StudentLogin(@S_ID, @password)
IF @Success = 1
    PRINT 'Login successful.';
ELSE
   PRINT 'Login failed.';
   
EXEC Procedures_StudentaddMobile 11,'01027556611'  --2.3.BB
SELECT * FROM dbo.FN_SemsterAvailableCourses('F24')  --2.3.CC
EXEC Procedures_StudentSendingCourseRequest 1,2,'111','2222'  --2.3.DD
EXEC Procedures_StudentSendingCHRequest 1,23,'credit_hours','Request for extra credit hours'  --2.3.EE
SELECT * FROM dbo.FN_StudentViewGP(1)  --2.3.FF

DECLARE @student_ID int = 1   --2.3.GG
DECLARE @return_Date DATE
SELECT @return_Date = dbo.FN_StudentUpcoming_installment(@student_ID)
PRINT 'Upcoming Installment Date is: ' + CAST (@return_Date AS VARCHAR(40))

SELECT * FROM dbo.FN_StudentViewSlot(1, 1)  --2.3.HH
Exec Procedures_StudentRegisterFirstMakeup 5,2,'sem4'  --2.3.II


DECLARE @OUTPUT BIT --2.3.JJ
SET @output= dbo.FN_StudentCheckSMEligiability (11,10)
PRINT (@output) 

EXEC Procedures_StudentRegisterSecondMakeup 11,10,'S24'  --2.3.KK
EXEC Procedures_ViewRequiredCourses 4, 'S24'  --2.3.LL
Exec Procedures_ViewOptionalCourse 1,'W23'   --2.3.MM
EXEC Procedures_ViewMS 1   --2.3.NN
EXEC Procedures_ChooseInstructor 1,2,3  --2.3.OO
                                                                                                                                                                                   


